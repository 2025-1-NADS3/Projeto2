package br.com.example.fecapayplus.data.model;

public class TransferenciaResponse {
    private boolean success;
    private String message;

    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
}